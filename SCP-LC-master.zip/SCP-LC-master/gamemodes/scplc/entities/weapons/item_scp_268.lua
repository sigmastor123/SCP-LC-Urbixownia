SWEP.Base 			= "item_slc_base"
SWEP.Language  		= "SCP268"

SWEP.WorldModel		= "models/thenextscp/scp268/berret.mdl"

SWEP.ShouldDrawWorldModel = false
SWEP.ShouldDrawViewModel = false

SWEP.SelectFont = "SCPHUDMedium"

SWEP.Toggleable = true
SWEP.Selectable = false
SWEP.EnableHolsterThink = true

SWEP.InvisTime = 15
SWEP.InvisCooldown = 120

function SWEP:Initialize()
	self:SetHoldType( self.HoldType )
	self:InitializeLanguage()

	self:AddNetworkVar( "Cooldown",  "Int" ) self:SetCooldown( 0 )
end

local InvisTime = 0
local NThink = 0
function SWEP:HolsterThink()
	local owner = self:GetOwner()

	if self:GetEnabled() and InvisTime <= CurTime() then
		self:WearOff()
	end

	if CurTime() > NThink then -- once per second
		if self:GetCooldown() > 0 then
			self:SetCooldown( self:GetCooldown() - 1 )
		end

		NThink = CurTime() + 1
	end
end

function SWEP:Equip()
	self.LastOwner = self.Owner
end

function SWEP:OnDrop()
	if self:GetEnabled() then
		self:WearOff()
	end
end

function SWEP:OnSelect()
	self.LastOwner = self.Owner
	local owner = self:GetOwner()

	if not self:GetEnabled() and self:GetCooldown() <= 0 then
		self:WearOn()
	elseif self:GetEnabled() then
		self:WearOff()
	elseif not self:GetEnabled() and self:GetCooldown() > 0 then
		PlayerMessage( "inviscooldown$"..self:GetCooldown(), owner, true )
	end
end

function SWEP:WearOff()
	local owner = self.LastOwner
	self:SetCooldown( self:GetCooldown() + self.InvisCooldown )
	PlayerMessage( "invisdeactivated", owner, true )
	self:SetEnabled( false )
	owner:SetNoDraw( false )
end

function SWEP:WearOn()
	local owner = self.LastOwner
	InvisTime = CurTime() + self.InvisTime
	PlayerMessage( "invisactivated$"..self.InvisTime, owner, true )
	self:SetEnabled( true )
	owner:SetNoDraw( true )
end

local PLAYER = FindMetaTable( "Player" )

function PLAYER:CheckInvisCap()
	local wep = self:GetWeapon( "item_scp_268" )

	if IsValid( wep ) and wep:GetEnabled() then
		return true
	else
		return false
	end
end

if not SERVER then return end

hook.Add( "Tick", "HatMassChanger", function()
	for k, v in ipairs( ents.GetAll() ) do
		if IsValid( v ) and v:GetClass() == "item_scp_268" then
			local phys = v:GetPhysicsObject()
			if IsValid( phys) then
				phys:SetMass( 25 )
			end
		end
	end
end )