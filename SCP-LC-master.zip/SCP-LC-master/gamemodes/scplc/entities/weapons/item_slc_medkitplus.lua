SWEP.Base 					= "item_slc_medkit"
SWEP.Language 				= "MEDKITPLUS"

SWEP.SCP914Upgrade = {
	[UPGRADE_MODE.VERY_FINE] = "item_scp_500"
}

SWEP.HealDmg 	= 60
SWEP.HealRand 	= 15
SWEP.Charges 	= 5
SWEP.MaxCharges = 5
SWEP.HealTime 	= 4

SWEP.Skin = 1

if CLIENT then
	SWEP.WepSelectIcon = Material( "slc/items/medkit.png" )
	SWEP.SelectColor = Color( 0, 123, 255, 255 )
end