SWEP.Base = "item_slc_base"
SWEP.Language = "SCP207"

SWEP.WorldModel = "models/weapons/scp_207/w_scp_207.mdl"
SWEP.ViewModel = "models/weapons/scp_207/v_scp_207.mdl"

SWEP.SelectFont = "SCPHUDMedium"
SWEP.UseHands = true

SWEP.HoldType = "slam"

-- Sound configuration
SWEP.PickupSound = "scp_207/pickup.mp3"
SWEP.DrinkSound = "scp_207/drink.mp3"

function SWEP:Initialize()
    self:SetHoldType(self.HoldType)
    self:InitializeLanguage()
end

function SWEP:Equip()
    if SERVER then
        local owner = self:GetOwner()
        if IsValid(owner) then
            owner:EmitSound(self.PickupSound)
        end
    end
end

function SWEP:PrimaryAttack()
    if CLIENT then return end

    local ply = self:GetOwner()
    if not IsValid(ply) then return end

    -- Prevent re-activation if effect already applied
    if ply:HasEffect("cola_drinker") then return end

    -- Apply the cola drinker effect to the player
    ply:ApplyEffect("cola_drinker")

    -- Play drinking animation and sound
    local vm = ply:GetViewModel()
    local seq = vm:LookupSequence("drink")
    if seq > 0 then
        vm:SendViewModelMatchingSequence(seq)
        local dur = vm:SequenceDuration(seq)
        ply:EmitSound(self.DrinkSound)
        self:SetNextPrimaryFire(CurTime() + dur)

        -- Remove the item after animation completes
        timer.Simple(dur, function()
            if IsValid(self) then
                self:Remove()
            end
        end)
    else
        -- If no animation, remove immediately with sound
        ply:EmitSound(self.DrinkSound)
        self:Remove()
    end
end

function SWEP:Deploy()
    local ply = self:GetOwner()
    if not IsValid(ply) then return false end

    local vm = ply:GetViewModel()
    local seq = vm:LookupSequence("draw")
    if seq > 0 then
        vm:SetCycle(0)
        vm:SetPlaybackRate(1)
        vm:SendViewModelMatchingSequence(seq)
    end

    return true
end

function SWEP:OnDrop()
    if SERVER then
        local ply = self:GetOwner()
        if IsValid(ply) then
            ply:RemoveEffect("cola_drinker")
        end
    end
end

function SWEP:Holster(wep)
    if SERVER then
        local ply = self:GetOwner()
        if IsValid(ply) then
            ply:RemoveEffect("cola_drinker")
        end
    end
    return true
end

SWEP.BoneAttachment = "ValveBiped.Bip01_R_Hand"
SWEP.PosOffset = Vector(4, -2, -1)
SWEP.AngOffset = Angle(180, 0, 0)

function SWEP:DrawWorldModel()
    local ply = self:GetOwner()
    if IsValid(ply) then
        local bone = ply:LookupBone(self.BoneAttachment)
        if bone then
            local matrix = ply:GetBoneMatrix(bone)
            if matrix then
                local pos, ang = LocalToWorld(self.PosOffset, self.AngOffset, matrix:GetTranslation(), matrix:GetAngles())
                self:SetRenderOrigin(pos)
                self:SetRenderAngles(ang)
                self:SetupBones()
                self:DrawModel()
                return
            end
        end
    end

    self:SetRenderOrigin()
    self:SetRenderAngles()
    self:SetupBones()
    self:DrawModel()
end