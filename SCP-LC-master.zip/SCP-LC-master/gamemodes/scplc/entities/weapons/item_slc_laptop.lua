SWEP.Base             = "item_slc_base"
SWEP.Language          = "uiucomputer"

SWEP.WorldModel        = "models/weapon_case/briefcase.mdl"

SWEP.ShouldDrawViewModel     = false
SWEP.ShouldDrawWorldModel     = false

SWEP.Selectable = false

SWEP.DrawCrosshair = false

if CLIENT then
	SWEP.WepSelectIcon = Material( "gamemodes/scplc/uiu_logo.png")
	SWEP.SelectColor = Color( 255, 255, 255, 255 )
end

hook.Add( "SLCCanPickupWeaponClass", "SLCGOCDevicePickup", function( ply, class )
	if class == "item_slc_laptop" and ply:SCPTeam() != TEAM_UIU then
		return false, "uiu_only"
	end
end )