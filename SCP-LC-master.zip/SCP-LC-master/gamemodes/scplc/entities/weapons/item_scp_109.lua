SWEP.Base 			= "item_slc_base"
SWEP.Language  		= "SCP109"

SWEP.WorldModel		= "models/props_junk/garbage_glassbottle001a.mdl"

SWEP.ShouldDrawWorldModel = false
SWEP.ShouldDrawViewModel = false

SWEP.SelectFont = "SCPHUDMedium"

SWEP.Toggleable = true
SWEP.Selectable = false
SWEP.EnableHolsterThink = true

SWEP.BoostTime = 15
SWEP.HealAmount = 15
SWEP.Uses = 3
SWEP.Cooldown = 90

function SWEP:Initialize()
	self:SetHoldType( self.HoldType )
	self:InitializeLanguage()

	self:AddNetworkVar( "Cooldown",  "Int" ) self:SetCooldown( 0 )
end

local NThink = 0
function SWEP:HolsterThink()
	if CurTime() > NThink then -- once per second
		if self:GetCooldown() > 0 then
			self:SetCooldown( self:GetCooldown() - 1 )
		end

		NThink = CurTime() + 1
	end
end

function SWEP:OnSelect()
	local owner = self:GetOwner()

	if self:GetCooldown() <= 0 then
		self:Drink()
	else
		PlayerMessage( "@WEAPONS.SCP109.cooldown$"..self:GetCooldown(), owner, true )
	end
end

function SWEP:OnDrop()
	timer.Destroy( "DrinkingFlask" )
end

function SWEP:Drink()
	local owner = self:GetOwner()
	self:SetCooldown( self:GetCooldown() + self.Cooldown )
	PlayerMessage( "@WEAPONS.SCP109.text_used", owner, true )

	local hp = math.min( owner:Health() + self.HealAmount, owner:GetMaxHealth() )
	local time = owner:GetStaminaBoost() - CurTime()
	if time < 0 then
		time = 0
	end
	time = time + self.BoostTime
	owner:SetHealth( hp )
	owner:SetStamina( owner:GetMaxStamina() )
	owner:SetStaminaBoost( CurTime() + time )
	owner:SetStaminaBoostDuration( time )
	self:EmitSound( "scp_lc/scp/109/drink"..math.random( 1, 2 )..".wav" )

	timer.Create( "DrinkingFlask", 0.75, 2, function()
		local hp = math.min( owner:Health() + self.HealAmount, owner:GetMaxHealth() )
		owner:SetHealth( hp )
		self:EmitSound( "scp_lc/scp/109/drink"..math.random( 1, 2 )..".wav" )
	end )
end