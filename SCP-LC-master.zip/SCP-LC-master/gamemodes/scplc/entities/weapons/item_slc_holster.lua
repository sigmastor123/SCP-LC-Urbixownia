SWEP.Base 		= "item_slc_base"
SWEP.Droppable 	= false
SWEP.Language 	= "HOLSTER"

SWEP.ShouldDrawViewModel 	= false
SWEP.ShouldDrawWorldModel 	= false

SWEP.SelectFont = "SCPHUDMedium"

SWEP.DrawCrosshair = true