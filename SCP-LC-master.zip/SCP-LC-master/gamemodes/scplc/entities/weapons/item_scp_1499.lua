SWEP.Base = "item_slc_base"
SWEP.Language = "SCP1499"

SWEP.PrintName = "SCP-1499"
SWEP.Author = "Giga Negron"
SWEP.Info = "Gas mask that transports wearer to another dimension"

SWEP.WorldModel = "models/scp1499/scp1499mask.mdl"
SWEP.HoldType = "normal"
SWEP.UseHands = true
SWEP.SelectFont = "SCPHUDMedium"

SWEP.Selectable = true
SWEP.Droppable = true
SWEP.Toggleable = false
SWEP.SingleUse = true  -- New property to mark as one-time use

function SWEP:Initialize()
    self:SetHoldType(self.HoldType)
    self:InitializeLanguage()
end

function SWEP:PrimaryAttack()
    if CLIENT then return end
    
    local owner = self:GetOwner()
    if not IsValid(owner) then return end
    
    -- Cooldown to prevent spamming
    if self.NextUse and self.NextUse > CurTime() then return end
    self.NextUse = CurTime() + 1
    
    -- Store original position
    self.OriginalPos = owner:GetPos()
    self.OriginalAng = owner:GetAngles()
    
    -- Teleport to void
    owner:SetPos(Vector(9999, 9999, 99999))
    owner:Freeze(true)
    
    -- Set return time (10 seconds)
    self.ReturnTime = CurTime() + 10
    
    -- Notification
    PlayerMessage("@WEAPONS.SCP1499.transport_message", owner, true)
    
    -- Mark as used (prevent multiple activations)
    self.HasBeenUsed = true
end

function SWEP:Think()
    if SERVER and self.ReturnTime and CurTime() >= self.ReturnTime then
        self:ReturnPlayer()
        if self.SingleUse and self.HasBeenUsed then
            self:Remove()
        end
    end
end

function SWEP:ReturnPlayer()
    local owner = self:GetOwner()
    if not IsValid(owner) then return end
    
    -- Return to original position
    if self.OriginalPos then owner:SetPos(self.OriginalPos) end
    if self.OriginalAng then owner:SetAngles(self.OriginalAng) end
    
    -- Unfreeze
    owner:Freeze(false)
    
    -- Notification
    PlayerMessage("@WEAPONS.SCP1499.return_message", owner, true)
    
    -- Clean up
    self.ReturnTime = nil
    self.OriginalPos = nil
    self.OriginalAng = nil
    
    -- Remove if single-use
    if self.SingleUse and self.HasBeenUsed then
        self:Remove()
    end
end

-- Rest of the code remains the same...
function SWEP:Holster()
    if SERVER and self.ReturnTime then
        self:ReturnPlayer()
    end
    return true
end

function SWEP:OnRemove()
    if SERVER and self.ReturnTime then
        self:ReturnPlayer()
    end
end

function SWEP:DrawWorldModel()
    if not IsValid(self:GetOwner()) then
        self:DrawModel()
    end
end