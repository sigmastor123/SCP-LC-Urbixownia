SWEP.Base = "weapon_scp_base"
SWEP.PrintName = "SCP-999"

SWEP.HoldType = "normal"

SWEP.HealRange = 150
SWEP.GroupHealRange = 300
SWEP.HealAmount = 30
SWEP.HealCooldown = 5
SWEP.GroupHealCooldown = 15
SWEP.SpeedBoostDuration = 10
SWEP.SpeedBoostMultiplier = 1.3
SWEP.SpeedBoostCooldown = 30

function SWEP:SetupDataTables()
    self:CallBaseClass("SetupDataTables")
    self:AddNetworkVar("NextHeal", "Float")
    self:AddNetworkVar("NextGroupHeal", "Float")
    self:AddNetworkVar("NextSpeedBoost", "Float")
    self:AddNetworkVar("SpeedBoostEnd", "Float")
end

function SWEP:Initialize()
    self:SetHoldType(self.HoldType)
    self:InitializeLanguage("SCP999")
    self:InitializeHUD()
end

function SWEP:Think()
    self:PlayerFreeze()
    
    local ct = CurTime()
    local owner = self:GetOwner()
    
    -- End speed boost if time is up
    if self:GetSpeedBoostEnd() > 0 and self:GetSpeedBoostEnd() <= ct then
        self:SetSpeedBoostEnd(0)
        if SERVER then
            owner:PopSpeed("SCP999_SpeedBoost")
        end
    end
end

function SWEP:PrimaryAttack()
    if CLIENT or ROUND.preparing or ROUND.post then return end
    
    local ct = CurTime()
    if self:GetNextHeal() > ct then return end
    
    local owner = self:GetOwner()
    local target = self:GetHealTarget()
    
    if not IsValid(target) then return end
    
    self:SetNextHeal(ct + self.HealCooldown)
    
    if SERVER then
        local maxHP = target:GetMaxHealth()
        target:SetHealth(math.min(target:Health() + self.HealAmount, maxHP))
        target:EmitSound("gamemodes/scplc/scp-999-sound_iXdMwzh.mp3")
        owner:EmitSound("gamemodes/scplc/scp-999-sound_iXdMwzh.mp3")
    end
end

function SWEP:SecondaryAttack()
    if CLIENT or ROUND.preparing or ROUND.post then return end
    
    local ct = CurTime()
    if self:GetNextGroupHeal() > ct then return end
    
    local owner = self:GetOwner()
    local pos = owner:GetPos()
    local healed = false
    
    self:SetNextGroupHeal(ct + self.GroupHealCooldown)
    
    if SERVER then
        for _, ply in ipairs(player.GetAll()) do
            if ply:Alive() and ply:GetPos():Distance(pos) <= self.GroupHealRange then
                local maxHP = ply:GetMaxHealth()
                if ply:Health() < maxHP then
                    ply:SetHealth(math.min(ply:Health() + (self.HealAmount * 0.5), maxHP))
                    healed = true
                end
            end
        end
        
        if healed then
            owner:EmitSound("gamemodes/scplc/scp-999-sound_iXdMwzh.mp3")
        end
    end
end

function SWEP:SpecialAttack()
    if CLIENT or ROUND.preparing or ROUND.post then return end
    
    local ct = CurTime()
    if self:GetNextSpeedBoost() > ct then return end
    
    local owner = self:GetOwner()
    self:SetNextSpeedBoost(ct + self.SpeedBoostCooldown)
    self:SetSpeedBoostEnd(ct + self.SpeedBoostDuration)
    
    if SERVER then
        owner:PushSpeed(self.SpeedBoostMultiplier, self.SpeedBoostMultiplier, -1, "SCP999_SpeedBoost")
        owner:EmitSound("gamemodes/scplc/scp-999-sound_iXdMwzh.mp3")
        
        owner:AddTimer("SCP999_SpeedBoost_End", self.SpeedBoostDuration, 1, function()
            if IsValid(owner) then
                owner:PopSpeed("SCP999_SpeedBoost")
            end
        end)
    end
end

function SWEP:GetHealTarget()
    local owner = self:GetOwner()
    local pos = owner:GetShootPos()
    local ang = owner:GetAimVector()
    
    local trace = util.TraceLine({
        start = pos,
        endpos = pos + ang * self.HealRange,
        filter = owner
    })
    
    local ent = trace.Entity
    if IsValid(ent) and ent:IsPlayer() and ent:Alive() and ent:GetPos():Distance(owner:GetPos()) <= self.HealRange then
        return ent
    end
    
    return nil
end

if CLIENT then
    local hud = SCPHUDObject("SCP999", SWEP)
    hud:AddCommonSkills()
    
    hud:AddSkill("heal")
        :SetButton("attack")
        :SetMaterial("", "smooth")
        :SetCooldownFunction("GetNextHeal")
    
    hud:AddSkill("group_heal")
        :SetButton("attack2")
        :SetMaterial("", "smooth")
        :SetCooldownFunction("GetNextGroupHeal")
    
    hud:AddSkill("speed_boost")
        :SetButton("scp_special")
        :SetMaterial("", "smooth")
        :SetCooldownFunction("GetNextSpeedBoost")
    
    hud:AddBar("boost_bar")
        :SetMaterial("", "smooth")
        :SetColor(Color(255, 215, 0))
        :SetTextFunction(function(swep)
            local time = swep:GetSpeedBoostEnd() - CurTime()
            if time < 0 then time = 0 end
            return math.Round(time).."s"
        end)
        :SetProgressFunction(function(swep)
            return (swep:GetSpeedBoostEnd() - CurTime()) / swep.SpeedBoostDuration
        end)
        :SetVisibleFunction(function(swep)
            return swep:GetSpeedBoostEnd() > CurTime()
        end)
end

-- SCP Hooks
SCPHook("SCP999", "EntityTakeDamage", function(target, dmg)
    if dmg:IsDamageType(DMG_DIRECT) or not IsValid(target) or not target:IsPlayer() or target:SCPClass() ~= CLASSES.SCP999 then return end
    
    local wep = target:GetSCPWeapon()
    if not IsValid(wep) then return end
    
    -- SCP-999 takes reduced damage
    dmg:ScaleDamage(0.7)
end)

SCPHook("SCP999", "SLCPlayerFootstep", function(ply, foot, snd)
    if ply:SCPClass() ~= CLASSES.SCP999 then return end
    
    local ct = CurTime()
    if not ply.Next999Step or ply.Next999Step < ct then
        ply.Next999Step = ct + 0.8
        ply:EmitSound("gamemodes/scplc/scp-999-sound_iXdMwzh.mp3")
    end
    
    return true
end)