SWEP.Base 		= "item_slc_battery"

SWEP.Power 		= 1337

if CLIENT then
	SWEP.SelectColor = Color( 255, 0, 0 )
end