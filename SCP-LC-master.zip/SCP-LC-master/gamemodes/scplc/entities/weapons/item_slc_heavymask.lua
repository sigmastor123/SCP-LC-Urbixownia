SWEP.Base 			= "item_slc_gasmask"
SWEP.Language 		= "HEAVYMASK"

SWEP.Durability		= 666

if CLIENT then
	SWEP.WepSelectIcon = Material( "slc/items/gas_mask.png" )
	SWEP.SelectColor = Color( 0, 100, 0 )
end