//SCORBOARD = nil

local function create_scoreboard()

end

/*AddGUISkin( "scoreboard", "template", {
	create = create_scoreboard,
	remove = function()
		SCOREBOARD:Remove()
	end,
	show =  function()
		SCOREBOARD:Show()
	end,
	hide = function()
		SCOREBOARD:Hide()
	end,
} )*/