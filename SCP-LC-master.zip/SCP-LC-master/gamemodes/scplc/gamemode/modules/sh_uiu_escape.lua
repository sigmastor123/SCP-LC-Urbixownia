local function uiu_escape( ply )
	local xp = 5000 -- ilosc expa
	
	for k, v in pairs( ply:GetWeapons() ) do
	if v:GetClass() != "item_slc_laptop" then continue end
	
	PlayerMessage( string.format( "uiulaptop$%i", xp ), ply )
	ply:AddXP( xp )
	end
	end
	
	hook.Add( "SLCPlayerEscaped", "SLCUIULaptop", uiu_escape )
	hook.Add( "SLCPlayerEscorted", "SLCUIULaptop", uiu_escape )